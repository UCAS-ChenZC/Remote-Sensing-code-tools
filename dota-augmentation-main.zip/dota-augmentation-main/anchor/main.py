# -*- coding: utf-8 -*-
import dota2yolo
import delClass
# dota2yolo.dota2yolo('/Users/aoxin/CODE/python/anchor/lableTxt', 'yolo-l2').d2y()

delClass.delclass('/Users/aoxin/CODE/python/anchor/dota-l2').remain_class_dota('L2')