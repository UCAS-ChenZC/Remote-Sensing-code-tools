import aug

A=aug.aug("/media/solid/LiuYD/旋转/images","/media/solid/LiuYD/旋转/labels","/media/solid/LiuYD/旋转/test","/media/solid/LiuYD/旋转/txt")# 原始图片路径 原始lables路径 扩充到的图片路径 扩充到的lables路径
A.Rotate(angle=180)

# A.RandomResize()
#A.AddWeather()
