=======
History
=======


v3.0 (2020) - developing
------------------------
* This version will reorganize the code to make it more readable.
* This version will only support Python3 and PyQt5.
* One Qt issue on Mac leaves in this version: Mac PyQt5 menubar not active until unfocusing-refocusing the app.
    * This bug may be from Qt, the temperal solution is listed as the link.
    * https://stackoverflow.com/questions/48738805/mac-pyqt5-menubar-not-active-until-unfocusing-refocusing-the-app
    * If anyone who have better solution, that will be much helpful.
* A small demo in .gif can be found under ./demo as demo_v2.5.gif and https://youtu.be/7D5lvol_QRA


v2.5 (2017) - roLabelImg
------------------------
* This is the version developed in 2017.
* Please find this version in branch v2.5-2017

1.3.2 (2017-05-18)
------------------

* Fix issues


1.3.1 (2017-05-11)
------------------

* Fix issues

1.3.0 (2017-04-22)
------------------

* Fix issues
* Add difficult tag
* Create new files for pypi

1.2.3 (2017-04-22)
------------------

* Fix issues

1.2.2 (2017-01-09)
------------------

* Fix issues
